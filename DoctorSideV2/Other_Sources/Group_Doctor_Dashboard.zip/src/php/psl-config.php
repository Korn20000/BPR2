<?php
define("HOST", "localhost");     // The host to connect to.
define("USER_DOC", "id3343620_secure_doctors_admin");    // Doctor database username. 
define("PASSWORD", "12345");    // The database password. 
define("DATABASE_DOC", "id3343620_secure_doctors_login");    // Doctor login database name.

define("USER_PAT", "id3343620_bachelor");    // Doctor database username. 
define("DATABASE_PAT", "id3343620_bachelor");    // Doctor login database name.

define("DEFAULT_ROLE", "member");

define("SECURE", TRUE);    // FOR DEVELOPMENT ONLY!!!! -> changed from false to TRUE

?>