<?php
define("HOST", "mysql.hostinger.com");     // The host to connect to.
define("USER_DOC", "u811754404_admin");    // Doctor database username. 
define("PASSWORD_DOC", "BOnd1g4tzxGS");    // The database password. 
define("DATABASE_DOC", "u811754404_docLo");    // Doctor login database name.
define("USER_PAT", "u811754404_Admpa");    // Doctor database username. 
define("DATABASE_PAT", "u811754404_patie");    // Doctor login database name.
define("PASSWORD_PAT", "t3LNYfC4M8UI");    // The database password. 
define("DEFAULT_ROLE", "member");
define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!! -> changed from false to TRUE
?>